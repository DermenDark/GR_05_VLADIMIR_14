from django.urls import re_path
from . import views
from django.contrib.auth import views as auth_views

app_name = "shop"

urlpatterns = [
    re_path(r'^profile/$', views.profile_view, name='profile'),
    re_path(r'^logout/$', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
    re_path(r'^cart/$', views.cart_view, name='cart'),
    re_path(r'^cart/add/(?P<pk>\d+)/$', views.add_to_cart, name='add_to_cart'),
    re_path(r'^cart/item/(?P<item_id>\d+)/add/$', views.cart_item_add, name='cart_item_plus'),
    re_path(r'^cart/item/(?P<item_id>\d+)/notadd/$', views.cart_item_notadd, name='cart_item_minus'),
    re_path(r'^cart/item/(?P<item_id>\d+)/delete/$', views.cart_item_delete, name='cart_item_delete'),
    re_path(r'^cart/checkout/$', views.checkout, name='checkout'),
]