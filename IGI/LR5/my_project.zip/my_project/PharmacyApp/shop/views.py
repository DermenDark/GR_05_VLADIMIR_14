import logging

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render

from .models import Cart, CartItem, Medication, Order, OrderItem

logger = logging.getLogger("shop")


@login_required(login_url="login_view")
def profile_view(request):
    logger.info("Открыт профиль пользователя %s", request.user)

    cart, _ = Cart.objects.get_or_create(user=request.user)
    cart_items = cart.items.select_related("medication").all()
    orders = request.user.orders.prefetch_related("items__medication").order_by("-created_at")

    return render(request, "shop/profile.html", {
        "profile_user": request.user,
        "cart": cart,
        "cart_items": cart_items,
        "orders": orders,
    })


@login_required(login_url="login_view")
def cart_view(request):
    logger.info("Открыта корзина пользователя %s", request.user)

    cart, _ = Cart.objects.get_or_create(user=request.user)
    items = cart.items.select_related("medication").all()

    return render(request, "shop/cart.html", {
        "cart": cart,
        "items": items,
        "total_cost": cart.total_cost,
    })


@login_required(login_url="login_view")
def add_to_cart(request, pk):
    medication = get_object_or_404(Medication, pk=pk)
    logger.info("Попытка добавить товар id=%s в корзину пользователем %s", pk, request.user)

    if medication.count <= 0:
        messages.error(request, "Товара нет в наличии.")
        logger.warning("Товар id=%s недоступен для добавления пользователем %s", pk, request.user)
        return redirect("catalog")

    cart, _ = Cart.objects.get_or_create(user=request.user)

    item, created = CartItem.objects.get_or_create(
        cart=cart,
        medication=medication,
        defaults={"quantity": 1},
    )

    if not created:
        if item.quantity < medication.count:
            item.quantity += 1
            item.save()
            messages.success(request, f"{medication.name} добавлен в корзину.")
            logger.info("Увеличено количество товара id=%s в корзине пользователем %s", pk, request.user)
        else:
            messages.warning(request, "Нельзя добавить больше, чем есть в наличии.")
            logger.warning("Превышено доступное количество товара id=%s пользователем %s", pk, request.user)
    else:
        messages.success(request, f"{medication.name} добавлен в корзину.")
        logger.info("Товар id=%s добавлен в корзину пользователем %s", pk, request.user)

    return redirect("shop:cart")


@login_required(login_url="login_view")
def cart_item_add(request, item_id):
    item = get_object_or_404(CartItem, pk=item_id, cart__user=request.user)

    if item.quantity < item.medication.count:
        item.quantity += 1
        item.save()
        logger.info("Увеличено количество позиции id=%s пользователем %s", item_id, request.user)
    else:
        messages.warning(request, "Нельзя добавить больше, чем есть в наличии.")
        logger.warning("Превышен лимит позиции id=%s пользователем %s", item_id, request.user)

    return redirect("shop:cart")


@login_required(login_url="login_view")
def cart_item_notadd(request, item_id):
    item = get_object_or_404(CartItem, pk=item_id, cart__user=request.user)

    if item.quantity > 1:
        item.quantity -= 1
        item.save()
        logger.info("Уменьшено количество позиции id=%s пользователем %s", item_id, request.user)
    else:
        item.delete()
        logger.warning("Позиция id=%s удалена из корзины пользователем %s", item_id, request.user)

    return redirect("shop:cart")


@login_required(login_url="login_view")
def cart_item_delete(request, item_id):
    item = get_object_or_404(CartItem, pk=item_id, cart__user=request.user)
    item.delete()
    logger.warning("Позиция id=%s удалена из корзины пользователем %s", item_id, request.user)
    return redirect("shop:cart")


@login_required(login_url="login_view")
@transaction.atomic
def checkout(request):
    logger.info("Попытка оформить заказ пользователем %s", request.user)

    cart, _ = Cart.objects.get_or_create(user=request.user)
    items = cart.items.select_related("medication").all()

    if not items.exists():
        messages.info(request, "Корзина пуста.")
        logger.warning("Пустая корзина у пользователя %s", request.user)
        return redirect("shop:cart")

    for item in items:
        if item.quantity > item.medication.count:
            messages.error(request, f"Недостаточно товара: {item.medication.name}")
            logger.error("Недостаточно товара %s для оформления заказа пользователем %s", item.medication.name, request.user)
            return redirect("shop:cart")

    order = Order.objects.create(
        user=request.user,
        total_cost=cart.total_cost,
        is_paid=False,
    )

    for item in items:
        OrderItem.objects.create(
            order=order,
            medication=item.medication,
            quantity=item.quantity,
            price=item.medication.cost,
        )
        item.medication.count -= item.quantity
        item.medication.save()

    items.delete()

    messages.success(request, f"Заказ #{order.id} успешно оформлен.")
    logger.info("Заказ #%s успешно оформлен пользователем %s", order.id, request.user)
    return redirect("shop:profile")