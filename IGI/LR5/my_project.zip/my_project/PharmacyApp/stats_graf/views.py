import base64
import logging
from io import BytesIO

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from django.contrib.auth.decorators import login_required, permission_required
from django.db.models import Sum
from django.db.models.functions import TruncDate
from django.shortcuts import render

from pharmacy.models import Sale, SaleItem, Medication, Employee

logger = logging.getLogger("pharmacy")


@login_required
@permission_required("pharmacy.view_sale", raise_exception=True)
def stats_view(request):
    logger.info("Открыта страница статистики пользователем %s", request.user)

    medications = Medication.objects.all()
    employees = Employee.objects.select_related("department").all()

    selected_medication_id = request.GET.get("medication")
    selected_employee_id = request.GET.get("employee")

    total_revenue = Sale.objects.filter(made=True).aggregate(
        total=Sum("total_cost")
    )["total"] or 0

    by_department = (
        Sale.objects.filter(made=True)
        .values("employee__department__name")
        .annotate(total=Sum("total_cost"))
        .order_by("-total")
    )

    medication_sales = None
    if selected_medication_id:
        medication_sales = (
            SaleItem.objects
            .filter(medication_id=selected_medication_id, sale__made=True)
            .select_related("sale", "sale__employee", "medication")
            .order_by("-sale__sale_date")
        )

    employee_sales = None
    if selected_employee_id:
        employee_sales = (
            Sale.objects
            .filter(made=True, employee_id=selected_employee_id)
            .select_related("employee")
            .order_by("-sale_date")
        )

    sales_qs = Sale.objects.filter(made=True)
    if selected_employee_id:
        sales_qs = sales_qs.filter(employee_id=selected_employee_id)
    if selected_medication_id:
        sale_ids = SaleItem.objects.filter(
            medication_id=selected_medication_id
        ).values_list("sale_id", flat=True)
        sales_qs = sales_qs.filter(id__in=sale_ids)

    sales_by_date = (
        sales_qs
        .annotate(date=TruncDate("sale_date"))
        .values("date")
        .annotate(total=Sum("total_cost"))
        .order_by("date")
    )

    fig, ax = plt.subplots()
    if sales_by_date:
        dates = [entry["date"].strftime("%d.%m") for entry in sales_by_date]
        totals = [entry["total"] for entry in sales_by_date]
        ax.bar(dates, totals)
        ax.set_xlabel("Дата")
        ax.set_ylabel("Выручка")
        ax.set_title("Продажи по датам")
        plt.xticks(rotation=45)
        plt.tight_layout()
    else:
        ax.text(0.5, 0.5, "Нет данных", ha="center", va="center")
        ax.set_title("Продажи по датам")
        logger.warning("Для статистики по датам нет данных")

    buf = BytesIO()
    fig.savefig(buf, format="png")
    buf.seek(0)
    graphic = base64.b64encode(buf.read()).decode("utf-8")
    buf.close()
    plt.close(fig)

    fig2, ax2 = plt.subplots()
    if by_department:
        dept_names = [d["employee__department__name"] or "Без отдела" for d in by_department]
        dept_totals = [d["total"] for d in by_department]
        ax2.pie(dept_totals, labels=dept_names, autopct="%1.1f%%", startangle=90)
        ax2.set_title("Выручка по отделам")
    else:
        ax2.text(0.5, 0.5, "Нет данных", ha="center", va="center")
        ax2.set_title("Выручка по отделам")
        logger.warning("Для статистики по отделам нет данных")

    buf2 = BytesIO()
    fig2.savefig(buf2, format="png")
    buf2.seek(0)
    graphic2 = base64.b64encode(buf2.read()).decode("utf-8")
    buf2.close()
    plt.close(fig2)

    context = {
        "total_revenue": total_revenue,
        "by_department": by_department,
        "medication_sales": medication_sales,
        "employee_sales": employee_sales,
        "medications": medications,
        "employees": employees,
        "selected_medication_id": selected_medication_id,
        "selected_employee_id": selected_employee_id,
        "graphic": graphic,
        "graphic2": graphic2,
    }
    return render(request, "stats_graf/stats.html", context)