from django.contrib import admin
from .models import (AboutCompany, News, Review, Term)

# Register your models here.
admin.site.register(AboutCompany)
admin.site.register(News)
admin.site.register(Review)
admin.site.register(Term)
