import logging

import requests
from django.shortcuts import render, get_object_or_404

from .models import Term, Review, AboutCompany, News
from .help_funk.filter import filter_news, filter_reviews, filter_terms

logger = logging.getLogger("info")


def index(request):
    logger.info("Открыта главная страница пользователем %s", request.user)

    all_info = []
    history_fact2 = None
    error_message = None
    if request.user.is_authenticated:
        appid = '63026ab922acdc159af4d7d5c6adca54'
        url = 'https://api.openweathermap.org/data/2.5/weather?q={}&units=metric&appid=' + appid

        city = request.GET.get('city', 'London')

        
        error = None

        response = requests.get(url.format(city))
        res = response.json()

        if res.get("cod") == 200:
            all_info.append({
                'city': city,
                'temp': res["main"]["temp"],
                'icon': res["weather"][0]["icon"]
            })
        else:
            error = "Город не найден"
            logger.error("API о погоде ответила с ошибкой: %s", res.get("cod"))

        api_url2 = "https://api.api-ninjas.com/v1/dayinhistoryq"

        try:
            response2 = requests.get(
                api_url2,
                headers={"X-Api-Key": "XYs4lfY3vc3uV7BsbrntM2PvZMiIeKLGzEd2a0X9"},
                timeout=5
            )

            if response2.status_code == 200:
                data = response2.json()
                if data:
                    history_fact2 = data[0].get("event") if isinstance(data, list) else data.get("event")
            elif response2.status_code == 404:
                error_message = "API временно недоступен"
            else:
                error_message = f"Ошибка API: {response2.status_code}"
        except requests.RequestException as exc:
            logger.error("Ошибка API-Ninjas: %s", exc)
            error_message = "Ошибка подключения к API"

    company = AboutCompany.objects.first()

    return render(request, "info/index.html", {
        "all_info": all_info ,
        "history_day2": history_fact2 or "Сегодня в истории: интересный факт будет добавлен позже",
        "company": company,
        "api_error": error_message
    })


def news(request):
    logger.info("Открыт список новостей пользователем %s", request.user)
    news_list = News.objects.all().order_by("-created_at")
    news_list = filter_news(request, news_list)

    return render(request, "info/news.html", {
        "news": news_list
    })


def news_detail(request, pk):
    logger.info("Открыта новость id=%s пользователем %s", pk, request.user)
    news = get_object_or_404(News, pk=pk, is_published=True)
    return render(request, "info/news_detail.html", {
        "news": news
    })


def reviews(request):
    logger.info("Открыт список отзывов пользователем %s", request.user)
    reviews_list = Review.objects.all().order_by("-created_at")
    reviews_list = filter_reviews(request, reviews_list)

    return render(request, "info/reviews.html", {
        "reviews": reviews_list
    })


def terms(request):
    logger.info("Открыт словарь терминов пользователем %s", request.user)
    terms_list = Term.objects.all().order_by("-created_at")
    terms_list = filter_terms(request, terms_list)

    return render(request, "info/terms.html", {
        "terms": terms_list
    })


def politic(request):
    logger.info("Открыта страница политики конфиденциальности пользователем %s", request.user)
    return render(request, "info/politic.html")