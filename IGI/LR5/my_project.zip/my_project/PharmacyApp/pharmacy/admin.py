from django.contrib import admin
from .models import (Department, Employee, CategoryMedication,
                     Medication, Sale, SaleItem, Supplier,
                     EmployeeAccount, Benefits, Coupons, Vacancy, UserProfile)

# Register your models here.
admin.site.register(Department)
admin.site.register(Employee)
admin.site.register(EmployeeAccount)
admin.site.register(CategoryMedication)
admin.site.register(Medication)
admin.site.register(Supplier)
admin.site.register(Sale)
admin.site.register(SaleItem)
admin.site.register(Benefits)
admin.site.register(Coupons)
admin.site.register(Vacancy)
admin.site.register(UserProfile)