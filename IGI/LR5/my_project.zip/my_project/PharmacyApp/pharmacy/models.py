from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import date
from django.conf import settings

class UserProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="profile",
        verbose_name="Пользователь",
    )
    birth_date = models.DateField(
        verbose_name="Дата рождения",
        null=True,
        blank=True,
        help_text="Введите дату рождения (дд.мм.гггг)",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Дата создания"
    )

    class Meta:
        verbose_name = "Профиль пользователя"
        verbose_name_plural = "Профили пользователей"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} — {self.birth_date or 'Дата не указана'}"

    @property
    def age(self):
        """Вычисление возраста на основе даты рождения"""
        if self.birth_date:
            today = date.today()
            return today.year - self.birth_date.year - (
                (today.month, today.day) < (self.birth_date.month, self.birth_date.day)
            )
        return None

    def clean(self):
        """Валидация возраста при сохранении"""
        if self.birth_date:
            today = date.today()
            age = self.age
            
            if age is not None and age < 18:
                from django.core.exceptions import ValidationError
                raise ValidationError({
                    'birth_date': 'Вам должно быть не менее 18 лет'
                })
            if age is not None and age > 120:
                from django.core.exceptions import ValidationError
                raise ValidationError({
                    'birth_date': 'Проверьте правильность даты рождения'
                })
    
    
# Pharmacy structure
class Department(models.Model):
    """Отделы аптеки"""
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name

phone_validator = RegexValidator(
    regex=r'^\+375 \((29|33)\) \d{3}-\d{2}-\d{2}$',
    message='Телефон должен быть в формате +375 (29) XXX-XX-XX'
)

class Employee(models.Model):
    name = models.CharField(max_length=30)
    department = models.ForeignKey(
        Department, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="employees"
    )
    photo = models.ImageField(upload_to='contacts/', default='def_ju59XtB.webp', blank=True, null=True)
    description = models.TextField(blank=True, null=True, verbose_name='Описание работы')
    phone = models.CharField(max_length=19, validators=[phone_validator], verbose_name='Телефон')
    email = models.EmailField(verbose_name='Почта')

# pharmacy/models.py
class EmployeeAccount(models.Model):
    name = models.CharField(max_length=30)
    date_of_birth = models.DateField(
        verbose_name="Дата рождения",
        null=True,
        blank=True
        )
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE, related_name='account')

    @property
    def age(self):
        today = timezone.localdate()
        years = today.year - self.date_of_birth.year
        if (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day):
            years -= 1
        return years

    def clean(self):
        super().clean()
        if self.date_of_birth:
            if self.age < 18:
                raise ValidationError({'date_of_birth': 'Возраст должен быть не меньше 18 лет.'})

class CategoryMedication(models.Model):
    """Категории медикаментов"""
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class Medication(models.Model):
    """Медикаменты"""
    name = models.CharField(max_length=30)
    category = models.ForeignKey(
        CategoryMedication,
        on_delete=models.CASCADE,
        related_name='medications'
    )
    description = models.TextField()
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    count = models.PositiveIntegerField()

    def __str__(self):
        return self.name

class Supplier(models.Model):
    """Поставщики"""
    name = models.CharField(max_length=30)
    medications = models.ManyToManyField(Medication, related_name='suppliers')

    def __str__(self):
        return self.name

class Sale(models.Model):
    """Продажи"""
    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='sales'
    )
    total_cost = models.DecimalField(max_digits=10, decimal_places=2)
    made = models.BooleanField(default=False)
    sale_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Sale #{self.id}"

class SaleItem(models.Model):
    """Позиции продажи"""
    sale = models.ForeignKey(
        Sale,
        on_delete=models.CASCADE,
        related_name='items'
    )
    medication = models.OneToOneField(
        Medication,
        on_delete=models.CASCADE,
        related_name='sale_item'
    )
    count = models.PositiveIntegerField()

class Benefits(models.Model):
    """Льготы"""
    name = models.CharField(max_length=100)
    min_age = models.PositiveIntegerField(null=True, blank=True)
    is_pensioner = models.BooleanField(default=False)
    is_disability = models.BooleanField(default=False)

    discount_cost = models.DecimalField(max_digits=10, decimal_places=2)
    discount_percent = models.PositiveSmallIntegerField(
        validators=[
            MinValueValidator(0),
            MaxValueValidator(100)
        ]
    )
    is_active = models.BooleanField(default=True)
    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()
    usage_limit = models.PositiveIntegerField(null=True, blank=True)
    used_count = models.PositiveIntegerField(default=0)
    def __str__(self):
        return f"Льгота от {self.min_age} лет"

class Coupons(models.Model):
    """Купоны"""
    discount_cost = models.DecimalField(max_digits=10, decimal_places=2)

    discount_percent = models.PositiveSmallIntegerField(
        validators=[
            MinValueValidator(0),
            MaxValueValidator(100)
        ]
    )
    is_active = models.BooleanField(default=True)
    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()
    usage_limit = models.PositiveIntegerField(null=True, blank=True)
    used_count = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.discount_percent}% - {self.discount_cost}"

class Vacancy(models.Model):
    """Вакансии"""
    title = models.CharField(max_length=200, verbose_name='Название вакансии')
    description = models.TextField(verbose_name='Описание')
    is_active = models.BooleanField(default=True, verbose_name='Активна')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата добавления')

    def __str__(self):
        return self.title