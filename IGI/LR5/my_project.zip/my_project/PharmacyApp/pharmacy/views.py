import logging

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import login as auth_login
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from .models import (
    Department,
    Employee,
    EmployeeAccount,
    CategoryMedication,
    Medication,
    Supplier,
    Sale,
    SaleItem,
    Benefits,
    Coupons,
    Vacancy,
)
from .help_funk.filter import (
    filter_medications,
    filter_departments,
    filter_employees,
    filter_employee_accounts,
    filter_suppliers,
    filter_sales,
    filter_saleitems,
    filter_categories,
    filter_benefits,
    filter_coupons,
    filter_vacancies,
)

logger = logging.getLogger("pharmacy")


def catalog(request):
    logger.info("Открыт каталог пользователем %s", request.user)

    all_categories = CategoryMedication.objects.all()
    medics = Medication.objects.select_related("category").all()
    medics = filter_medications(request, medics)

    return render(request, "pharmacy/catalog.html", {
        "all_info": medics,
        "all_categors": all_categories,
    })


@login_required
@permission_required("pharmacy.add_medication", raise_exception=True)
def create_medication(request):
    categories = CategoryMedication.objects.all()

    if request.method == "POST":
        Medication.objects.create(
            name=request.POST.get("name"),
            category_id=request.POST.get("category"),
            description=request.POST.get("description"),
            cost=request.POST.get("cost"),
            count=request.POST.get("count"),
        )
        logger.info("Создан медикамент пользователем %s", request.user)
        return redirect("catalog")

    logger.info("Открыта форма создания медикамента пользователем %s", request.user)
    return render(request, "medications/create.html", {
        "categories": categories,
    })


@login_required
@permission_required("pharmacy.change_medication", raise_exception=True)
def edit_medication(request, pk):
    medic = get_object_or_404(Medication, pk=pk)
    categories = CategoryMedication.objects.all()

    if request.method == "POST":
        medic.name = request.POST.get("name")
        medic.category_id = request.POST.get("category")
        medic.description = request.POST.get("description")
        medic.cost = request.POST.get("cost")
        medic.count = request.POST.get("count")
        medic.save()
        logger.info("Изменен медикамент id=%s пользователем %s", pk, request.user)
        return redirect("catalog")

    logger.info("Открыта форма редактирования медикамента id=%s пользователем %s", pk, request.user)
    return render(request, "medications/edit.html", {
        "medic": medic,
        "categories": categories,
    })


@login_required
@permission_required("pharmacy.delete_medication", raise_exception=True)
def delete_medication(request, pk):
    medic = get_object_or_404(Medication, pk=pk)

    if request.method == "POST":
        medic.delete()
        logger.warning("Удален медикамент id=%s пользователем %s", pk, request.user)
        return redirect("catalog")

    logger.info("Открыта форма удаления медикамента id=%s пользователем %s", pk, request.user)
    return render(request, "medications/delete.html", {
        "medic": medic,
    })


def promo(request):
    logger.info("Открыта страница промокодов пользователем %s", request.user)
    return render(request, "pharmacy/promo.html", {
        "benefits": Benefits.objects.filter(is_active=True),
        "coupons": Coupons.objects.filter(is_active=True),
    })


def vacancies(request):
    logger.info("Открыта страница вакансий пользователем %s", request.user)
    vacancies_qs = Vacancy.objects.filter(is_active=True).order_by("-created_at")
    vacancies_qs = filter_vacancies(request, vacancies_qs)

    return render(request, "pharmacy/vacancies.html", {
        "vacancies": vacancies_qs
    })


def contacts(request):
    logger.info("Открыта страница контактов пользователем %s", request.user)
    return render(request, "pharmacy/contacts.html", {
        "employee": Employee.objects.select_related("department").all()
    })


def login_view(request):
    login_form = AuthenticationForm(request, data=request.POST or None)
    register_form = UserCreationForm(request.POST or None)

    if request.method == "POST":
        action = request.POST.get("action")

        if action == "login":
            if login_form.is_valid():
                user = login_form.get_user()
                auth_login(request, user)
                logger.info("Успешный вход пользователя %s", user)
                return redirect("about_company")
            logger.warning("Ошибка формы входа у пользователя %s", request.user)

        if action == "register":
            if register_form.is_valid():
                user = register_form.save()
                auth_login(request, user)
                logger.info("Успешная регистрация пользователя %s", user)
                return redirect("about_company")
            logger.warning("Ошибка формы регистрации у пользователя %s", request.user)

    logger.info("Открыта страница входа/регистрации пользователем %s", request.user)
    return render(request, "pharmacy/login.html", {
        "login_form": login_form,
        "register_form": register_form,
    })


@login_required
def profil_view(request):
    logger.info("Открыт профиль/кабинет пользователем %s", request.user)

    login_form = AuthenticationForm(request, data=request.POST or None)
    register_form = UserCreationForm(request.POST or None)

    if request.method == "POST":
        action = request.POST.get("action")

        if action == "login":
            if login_form.is_valid():
                user = login_form.get_user()
                auth_login(request, user)
                logger.info("Успешный вход пользователя %s из профиля", user)
                return redirect("about_company")
            logger.warning("Ошибка формы входа из профиля у пользователя %s", request.user)

        if action == "register":
            if register_form.is_valid():
                user = register_form.save()
                auth_login(request, user)
                logger.info("Успешная регистрация пользователя %s из профиля", user)
                return redirect("about_company")
            logger.warning("Ошибка формы регистрации из профиля у пользователя %s", request.user)

    return render(request, "pharmacy/login.html", {
        "login_form": login_form,
        "register_form": register_form,
    })


@login_required
@permission_required("pharmacy.view_department", raise_exception=True)
def department_list(request):
    logger.info("Открыт список отделов пользователем %s", request.user)
    departments = Department.objects.prefetch_related("employees").order_by("name")
    departments = filter_departments(request, departments)

    return render(request, "pharmacy/departments.html", {
        "departments": departments
    })


@login_required
@permission_required("pharmacy.view_employee", raise_exception=True)
def employee_list(request):
    logger.info("Открыт список сотрудников пользователем %s", request.user)
    employees = Employee.objects.select_related("department").order_by("name")
    employees = filter_employees(request, employees)

    return render(request, "pharmacy/employees.html", {
        "employees": employees,
        "all_departments": Department.objects.all(),
    })


@login_required
@permission_required("pharmacy.view_employeeaccount", raise_exception=True)
def employeeaccount_list(request):
    logger.info("Открыт список учетных записей сотрудников пользователем %s", request.user)
    employeeaccounts = EmployeeAccount.objects.select_related("employee").all()
    employeeaccounts = filter_employee_accounts(request, employeeaccounts)

    return render(request, "pharmacy/employee_accounts.html", {
        "employeeaccounts": employeeaccounts,
        "all_employees": Employee.objects.all(),
    })


@login_required
@permission_required("pharmacy.view_supplier", raise_exception=True)
def supplier_list(request):
    logger.info("Открыт список поставщиков пользователем %s", request.user)
    suppliers = Supplier.objects.prefetch_related("medications").order_by("name")
    suppliers = filter_suppliers(request, suppliers)

    return render(request, "pharmacy/suppliers.html", {
        "suppliers": suppliers,
        "all_medications": Medication.objects.all(),
    })


@login_required
@permission_required("pharmacy.view_sale", raise_exception=True)
def sale_list(request):
    logger.info("Открыт список продаж пользователем %s", request.user)
    sales = (
        Sale.objects
        .select_related("employee")
        .prefetch_related("items__medication")
        .order_by("-sale_date")
    )
    sales = filter_sales(request, sales)

    return render(request, "pharmacy/sales.html", {
        "sales": sales,
        "all_employees": Employee.objects.all(),
    })


@login_required
@permission_required("pharmacy.view_saleitem", raise_exception=True)
def saleitem_list(request):
    logger.info("Открыт список позиций продаж пользователем %s", request.user)
    saleitems = SaleItem.objects.select_related("sale", "medication")
    saleitems = filter_saleitems(request, saleitems)

    return render(request, "pharmacy/saleitems.html", {
        "saleitems": saleitems,
        "all_sales": Sale.objects.all(),
        "all_medications": Medication.objects.all(),
    })


@login_required
@permission_required("pharmacy.view_categorymedication", raise_exception=True)
def category_list(request):
    logger.info("Открыт список категорий медикаментов пользователем %s", request.user)
    categories = CategoryMedication.objects.prefetch_related("medications").order_by("name")
    categories = filter_categories(request, categories)

    return render(request, "pharmacy/categories.html", {
        "categories": categories
    })


@login_required
@permission_required("pharmacy.view_benefits", raise_exception=True)
def benefits_list(request):
    logger.info("Открыт список льгот пользователем %s", request.user)
    benefits = Benefits.objects.all()
    benefits = filter_benefits(request, benefits)

    return render(request, "pharmacy/benefits.html", {
        "benefits": benefits
    })


@login_required
@permission_required("pharmacy.view_coupons", raise_exception=True)
def coupons_list(request):
    logger.info("Открыт список купонов пользователем %s", request.user)
    coupons = Coupons.objects.all()
    coupons = filter_coupons(request, coupons)

    return render(request, "pharmacy/coupons.html", {
        "coupons": coupons
    })


@login_required
@permission_required("pharmacy.view_vacancy", raise_exception=True)
def vacancy_list(request):
    logger.info("Открыт список вакансий пользователем %s", request.user)
    vacancies = Vacancy.objects.all().order_by("-created_at")
    vacancies = filter_vacancies(request, vacancies)

    return render(request, "pharmacy/vacancies.html", {
        "vacancies": vacancies
    })